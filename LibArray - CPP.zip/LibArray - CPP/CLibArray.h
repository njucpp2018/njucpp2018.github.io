#ifndef __CLIBARRAY__
#define __CLIBARRAY__


class CArray
{

} ;






#endif