#include "stdafx.h" 

#include "FigureManager.h"
#include "BlackBoard.h"

using std::cout; 
using std::endl;

void FigureManager::input(std::istream &is)
{
	while (1)
	{
		int type; 

		cout << "input type(1 : Circle, 2 : Line, 3 : Rectangle, 0 : Quit)" << endl;
		is >> type; 

		switch (type)
		{	
		case 0:
			return; 
			break; 
		case 1: // Բ
			Circle circle; 
			std::cout << "Center X: "; 
			is >> circle._x; 

			std::cout << "Center Y: "; 
			is >> circle._y; 

			std::cout << "Radius: "; 
			is >> circle._radius;  

			_circls.push_back(circle); 
			break;
		case 2: // ��
			Line line; 
			std::cout << "X1: "; 
			is >> line._x1; 
			std::cout << "Y1: "; 
			is >> line._y1; 

			std::cout << "X2: "; 
			is >> line._x2; 
			std::cout << "Y2: "; 
			is >> line._y2; 
			_lines.push_back(line); 
			break;
		case 3: // ����
			Rectangle rectangle; 
			std::cout << "Left: "; 
			is >> rectangle._left; 
			std::cout << "Top: "; 
			is >> rectangle._top; 

			std::cout << "Right: "; 
			is >> rectangle._right; 
			std::cout << "Bottom: "; 
			is >> rectangle._bottom; 
			_rectangles.push_back(rectangle); 
			break;
		}
	}
}

void FigureManager::display(BlackBoard &board)
{
	// ������input�������ͼ�����������λ���
	for (Circles::iterator iter = _circls.begin(); iter != _circls.end(); ++iter)
	{
		board.DrawCircle(iter->_x, iter->_y, iter->_radius); 
	}
	for (Lines::iterator iter = _lines.begin(); iter != _lines.end(); ++iter)
	{
		board.DrawLine(iter->_x1, iter->_y1, iter->_x2, iter->_y2); 
	}
	for (Rectangles::iterator iter = _rectangles.begin(); iter != _rectangles.end(); ++iter)
	{
		board.DrawLine(iter->_left, iter->_top, iter->_right, iter->_top); 
		board.DrawLine(iter->_left, iter->_bottom, iter->_right, iter->_bottom); 
		board.DrawLine(iter->_left, iter->_top, iter->_left, iter->_bottom); 
		board.DrawLine(iter->_right, iter->_top, iter->_right, iter->_bottom); 
	}

}

// ������ʵ����ҪһЩ��Ҫ�ĳ�ʼ�����ɷ�����������У�main���������
// ���û�У������
void InitiateFigureManager()
{

}


