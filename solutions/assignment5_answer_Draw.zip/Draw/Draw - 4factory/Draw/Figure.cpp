#include "stdafx.h"

#include "Figure.h"