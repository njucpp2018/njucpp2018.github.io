# C++与面向对象程序设计
## 课程信息

授课时间：2017年秋

授课老师：

[于耀](http://ese.nju.edu.cn/faculty.php?name=yuyao&lang=cn)  allanyu@nju.edu.cn

助教：陈菲、张延

作业上传：esecpp2017@163.com

备注：点击Lec可下载相应课件；点击Assignment可下载相应作业及答案

## 阅读材料

[我在南大的七年](http://mindhacks.cn/2009/05/17/seven-years-in-nju/)

[学习C++：实践者的方法](http://blog.csdn.net/pongba/article/details/1930150)

[C++ reference](http://en.cppreference.com/w/)

## 课程表

× [assignment1]
