// Draw.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <iostream>
#include <math.h>


#include "FigureManager.h"
#include "BlackBoard.h"
#include "Circle.h"
#include "Line.h"
#include "Rectangle.h"
#include "Triangle.h"

// TextBoard board; 
BlackBoard board; 

int x_center = 0, y_center = 0; 

void ReshapeCallback(int width, int height)
{
	board.UpdateWindowSize(width, height); 
}

void TimerCallback(int value)
{
	y_center += 10; 
	board.Update(); 

	board.InitTimerCallback(500, TimerCallback, -1); 
}

void KeyboardCallback(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'q':
		exit(0);
		break; 
	case 'w':
		y_center += 10; 
		break; 
	case 'a':
		x_center -= 10; 
		break; 
	case 's':
		y_center -= 10; 
		break; 
	case 'd':
		x_center += 10; 
		break; 
	case 'f':
		board.InitTimerCallback(500, TimerCallback, 0); 
		break; 
	}
	
	board.Update(); 
}

void DisplayCallback()
{

	board.Clear(); 
	board.SetColor(1, 0, 1); 

	board.DrawCircle(20, 20, 100);

	board.DrawLine(20, 20, 100, 100); 


	board.DrawLine(20,  40,  20,  120); 
	board.DrawLine(20,  120, 100, 120); 
	board.DrawLine(100, 120, 100, 40); 
	board.DrawLine(100, 40,  20,  40); 


	board.DrawCircle(x_center + 40, y_center + 40, 100);
	

	FigureManager::handle().display(); 

	board.Flush(); 
}

int _tmain(int argc, _TCHAR* argv[])
{
    FigureManager::installFactory(new Factory<Circle>("Circle", FigureManager::assignID())); 
    FigureManager::installFactory(new Factory<Line>("Line", FigureManager::assignID())); 
    FigureManager::installFactory(new Factory<Triangle>("Triangle", FigureManager::assignID())); 
    FigureManager::installFactory(new Factory<Rectangle>("Rectangle", FigureManager::assignID())); 

    FigureManager::handle().input(); 




	board.InitCommandLine(&argc, (char **)argv); 
	board.InitWindowSize(800, 800); 
	board.InitDisplayCallback(DisplayCallback); 
	board.InitKeyboardCallback(KeyboardCallback); 
	board.InitReshapeCallback(ReshapeCallback); 
	
	board.Show(); 

    system("PAUSE"); 
	return 0;
}

