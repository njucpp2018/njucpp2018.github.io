#ifndef __FIGURE__
#define __FIGURE__


class Circle
{
public:
	int _x; 
	int _y; 
	int _radius;  
}; 

class Line
{
public:
	int _x1; 
	int _y1; 
	int _x2; 
	int _y2; 
};

class Rectangle
{
public:
	int _left; 
	int _top; 
	int _right; 
	int _bottom; 
};



#endif // #ifndef __FIGURE__

